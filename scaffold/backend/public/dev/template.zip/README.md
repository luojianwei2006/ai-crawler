# 插件开发模板

## 目录
- `manifest.json`：插件元信息（钩子点、权限声明、Tools/Resources）。钩子仅允许：
  onBeforeCrawl / onAfterParse / onError / onAfterCrawl。
- `bootstrap.php`：插件入口，由平台在**子进程沙箱**中执行。

## 协议
1. 平台调用：`php -d disable_functions=... bootstrap.php <base64(json)>`
2. 你的代码读取 `argv[1]`（base64 后的 JSON：url / depth / cookie / model / js_render）。
3. 输出用 NDJSON 到 stdout：
   - 日志：`{"t":"log","level":"info","message":"..."}`
   - 结果（末行）：`{"t":"result","ok":true,"items":[...]}`
4. 复用平台 `CrawlerService` 引擎；你只写**解析规则**（见 bootstrap.php 的 `$parseRule`）。

## 安全
- 不可使用 exec/shell_exec/system/popen/proc_open 等危险函数，上架会自动扫描并驳回。
- 需要 command 权限须管理员显式授权。

## 打包上传
`zip my-plugin.zip manifest.json bootstrap.php` → 平台“插件开发”页上传 → 自动扫描 → 管理员审核 → 上架。
