<?php
/**
 * 插件入口（开发者模板）
 * 平台以子进程沙箱运行本文件：php -d disable_functions=... bootstrap.php <base64输入>
 * 输入 argv[1] = base64(json)，含 {url, depth, cookie?, model?, js_render?}
 * 输出协议（NDJSON 到 stdout）：
 *   日志：{"t":"log","level":"info","message":"..."}
 *   结果（末行）：{"t":"result","ok":true,"items":[...]}
 */

$base = getenv('APP_BASE_PATH') ?: '/var/www';
require_once $base . '/vendor/autoload.php';

use App\Plugins\PluginManifest;
use App\Services\CrawlerService;
use GuzzleHttp\Client as Guzzle;

$input = json_decode(base64_decode($argv[1] ?? ''), true) ?? [];
$emit = function (string $level, string $msg): void {
    fwrite(STDOUT, json_encode(['t' => 'log', 'level' => $level, 'message' => $msg]) . "\n");
};

try {
    $url   = $input['url'] ?? '';
    $depth = (int) ($input['depth'] ?? 1);
    $js    = (bool) ($input['js_render'] ?? false);

    $manifest = PluginManifest::fromJson([
        'name' => 'my-plugin', 'developer' => 'you', 'version' => '1.0.0',
        'description' => '我的采集插件', 'updated_at' => date('Y-m-d'),
        'hooks' => ['onBeforeCrawl', 'onAfterParse', 'onError'],
        'permissions' => ['network' => true, 'filesystem' => false, 'command' => false],
        'tools' => [], 'resources' => [],
    ]);
    $svc = new CrawlerService(new Guzzle(), $manifest);

    // TODO: 在此编写你的"解析规则"（仅解析，不碰抓取引擎）
    $parseRule = function (\Symfony\Component\DomCrawler\Crawler $c, string $cur) {
        return [
            'url'   => $cur,
            'title' => $c->filter('title')->count() ? $c->filter('title')->text() : '',
        ];
    };

    $result = $svc->crawl($url, $depth, $parseRule, $emit, $js);
    fwrite(STDOUT, json_encode(['t' => 'result', 'ok' => $result['ok'] ?? false, 'items' => $result['items'] ?? []]) . "\n");
} catch (\Throwable $e) {
    $emit('error', 'onError: ' . $e->getMessage());
    fwrite(STDOUT, json_encode(['t' => 'result', 'ok' => false, 'items' => []]) . "\n");
}
